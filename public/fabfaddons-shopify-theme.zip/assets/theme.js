// FABFaddons Shopify OS 2.0 Theme JavaScript
document.addEventListener('DOMContentLoaded', () => {
  // Cart Drawer
  const cartTrigger = document.querySelector('[data-cart-drawer-trigger]');
  const cartDrawer = document.querySelector('#cart-drawer');
  const cartOverlay = document.querySelector('#cart-drawer-overlay');
  const cartClose = document.querySelector('[data-cart-drawer-close]');

  function openCart() {
    if (cartDrawer) cartDrawer.classList.add('active');
    if (cartOverlay) cartOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    refreshCartDrawer();
  }

  function closeCart() {
    if (cartDrawer) cartDrawer.classList.remove('active');
    if (cartOverlay) cartOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (cartTrigger) cartTrigger.addEventListener('click', openCart);
  if (cartClose) cartClose.addEventListener('click', closeCart);
  if (cartOverlay) cartOverlay.addEventListener('click', closeCart);

  // Intercept all /cart/add form submissions
  document.addEventListener('submit', async (e) => {
    const form = e.target.closest('form[action*="/cart/add"]');
    if (!form) return;
    e.preventDefault();

    const submitBtn = form.querySelector('[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;

    try {
      const res = await fetch('/cart/add.js', {
        method: 'POST',
        body: new FormData(form)
      });
      if (res.ok) {
        openCart();
      } else {
        form.submit();
      }
    } catch (err) {
      form.submit();
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  });

  // Refresh Cart Drawer Content
  async function refreshCartDrawer() {
    try {
      const res = await fetch('/cart.js');
      const cart = await res.json();
      
      // Update badge
      document.querySelectorAll('[data-cart-count-badge]').forEach(badge => {
        badge.textContent = cart.item_count;
        badge.style.display = cart.item_count > 0 ? 'inline-flex' : 'none';
      });

      // Update drawer subtotal
      const subtotalEl = document.querySelector('[data-cart-drawer-subtotal]');
      if (subtotalEl) {
        subtotalEl.textContent = formatMoney(cart.total_price);
      }

      // Update free shipping bar
      const threshold = (window.themeSettings?.freeShippingThreshold || 250) * 100;
      const progressEl = document.querySelector('[data-shipping-progress]');
      const messageEl = document.querySelector('[data-shipping-message]');
      if (progressEl && messageEl) {
        const percent = Math.min(100, Math.round((cart.total_price / threshold) * 100));
        progressEl.style.width = percent + '%';
        if (cart.total_price >= threshold) {
          messageEl.textContent = 'Complimentary UAE Express Delivery Unlocked!';
        } else {
          const away = formatMoney(threshold - cart.total_price);
          messageEl.textContent = `Add ${away} more for Complimentary Delivery`;
        }
      }
    } catch (e) {
      console.warn('Could not refresh cart drawer', e);
    }
  }

  function formatMoney(cents) {
    const aed = (cents / 100).toFixed(0);
    return `AED ${aed}`;
  }

  // Variant Change Handler on Product Pages
  const variantRadios = document.querySelectorAll('input[type="radio"][name="id"]');
  variantRadios.forEach(radio => {
    radio.addEventListener('change', () => {
      const price = radio.dataset.price;
      const comparePrice = radio.dataset.comparePrice;
      const available = radio.dataset.available === 'true';

      const priceEl = document.querySelector('[data-product-price]');
      if (priceEl && price) priceEl.textContent = price;

      const compareEl = document.querySelector('[data-product-compare-price]');
      if (compareEl) {
        if (comparePrice) {
          compareEl.textContent = comparePrice;
          compareEl.style.display = 'inline';
        } else {
          compareEl.style.display = 'none';
        }
      }

      const addBtn = document.querySelector('[data-add-to-cart-button]');
      if (addBtn) {
        addBtn.disabled = !available;
        addBtn.textContent = available ? 'Add to Bag' : 'Sold Out';
      }
    });
  });

  // Quantity Steppers
  document.querySelectorAll('[data-quantity-btn]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input[name="quantity"]');
      if (!input) return;
      let val = parseInt(input.value) || 1;
      if (btn.dataset.quantityBtn === 'plus') {
        input.value = val + 1;
      } else if (val > 1) {
        input.value = val - 1;
      }
    });
  });

  // Simple Accordion Handler
  document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
      const content = header.nextElementSibling;
      if (!content) return;
      const isVisible = content.style.display === 'block';
      content.style.display = isVisible ? 'none' : 'block';
    });
  });
});
